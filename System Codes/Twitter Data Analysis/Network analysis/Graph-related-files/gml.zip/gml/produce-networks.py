import networkx as nx
import pandas as pd
import pickle

# generate a network from an input gml file 
def gen_network(filename):
    # G = nx.MultiDiGraph()
    G = nx.read_gml(filename)
    G1 = nx.DiGraph(G)
    return G1 


# calculate non weighted degree centrality, normalised betweenness centrality and normalised closeness centrality of the input network 
# create DataFrame using Pandas of these three measures
# return nothing
# store in pickle file 
def gen_centrality(graph,outputfile):
    bc = nx.betweenness_centrality(graph,normalized=True)
    dc = nx.degree_centrality(graph)
    cc = nx.closeness_centrality(graph)

    #create dataFrame
    degree_centrality = pd.DataFrame(list(dc.items()),columns=['User name','degree centrality'])
    betweenness_centrality = pd.DataFrame(list(bc.items()),columns=['User name','betweenness centrality'])
    closeness_centrality = pd.DataFrame(list(cc.items()),columns=['User name','closeness centrality'])

    # merge dataframe
    temp = degree_centrality.merge(betweenness_centrality, left_on='User name', right_on='User name')
    all_data = temp.merge(closeness_centrality,left_on='User name', right_on='User name')

    #store into pickle file 
    f = open(outputfile,"wb")
    pickle.dump(all_data,f)
    f.close()

    return 

# sort by degree centrality 
def dc_sort(input_pickle_file):

    # read from pickle file
    with open(input_pickle_file,'rb') as f:
        all_data = pickle.load(f)

    all_data.sort_values(by=['degree centrality'],ascending =False)
    return  

# sort by closeness centrality 
def cc_sort(input_pickle_file):

    # read from pickle file
    with open(input_pickle_file,'rb') as f:
        all_data = pickle.load(f)

    all_data.sort_values(by=['closeness centrality'],ascending =False)
    return  

# sort by betweenness centrality 
def bc_sort(input_pickle_file):

    # read from pickle file
    with open(input_pickle_file,'rb') as f:
        all_data = pickle.load(f)

    all_data.sort_values(by=['betweenness centrality'],ascending =False)
    return  

# # for i in range(25,26):
#     filename = '2019-09-' + str(i) + '.gml'
#     graph = gen_network(filename)
#     outputfile = '2019-09-' + str(i) + '.pkl'
#     gen_centrality(graph,outputfile)

graph = gen_network('2019-10-08.gml')
gen_centrality(graph,'2019-10-08.pkl')